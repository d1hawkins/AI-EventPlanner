# AI Event Planner Application Package
"""
AI Event Planner - A comprehensive event planning application with AI agents.
"""

__version__ = "1.0.0"
__author__ = "AI Event Planner Team"
