#!/bin/bash
set -e

# Install dependencies with explicit packages
pip install -r requirements.txt
pip install uvicorn gunicorn fastapi sqlalchemy alembic psycopg2-binary

# Run database migrations using the migrate.py script
python -m scripts.migrate

# Start the application
gunicorn app.main_saas:app -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
