#!/bin/bash
set -e

# Run database migrations
python -m scripts.migrate

# Start the application
gunicorn app.main_saas:app -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
