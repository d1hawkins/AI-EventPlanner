import os
import sys
import subprocess
import time

def main():
    print("Starting deployment process...")
    
    # Install dependencies
    print("Installing dependencies...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
    
    # Run database migrations
    print("Running database migrations...")
    try:
        subprocess.check_call([sys.executable, "-m", "scripts.migrate"])
    except Exception as e:
        print(f"Warning: Migration failed: {e}")
    
    # Start the application
    print("Starting the application...")
    os.environ["PORT"] = "8000"
    subprocess.check_call([
        sys.executable, "-m", "uvicorn", "app.main_saas:app", 
        "--host", "0.0.0.0", "--port", "8000"
    ])

if __name__ == "__main__":
    main()
